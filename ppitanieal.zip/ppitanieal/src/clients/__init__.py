"""
Client modules for external services (Supabase, ChatGPT)
""" 